package com.priya.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PriyaHome() }
    }
}

private val PriyaScheme = darkColorScheme(
    primary = Color(0xFF75E6FF),
    secondary = Color(0xFFB69CFF),
    background = Color(0xFF070B16),
    surface = Color(0xFF111A2B)
)

@Composable
private fun PriyaHome() {
    MaterialTheme(colorScheme = PriyaScheme) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF070B16)) {
            Column(
                Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("PRIYA", color = Color(0xFFB8F2FF), fontSize = 20.sp,
                        fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                    Text("● READY", color = Color(0xFF78E6C0), fontSize = 11.sp)
                }
                Spacer(Modifier.height(42.dp))
                HologramOrb()
                Spacer(Modifier.height(28.dp))
                Text("Hello! আমি প্রিয়া।", color = Color.White, fontSize = 25.sp,
                    fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text("বলো, আজ তোমাকে কীভাবে সাহায্য করতে পারি?",
                    color = Color(0xFFB5C4D9), fontSize = 14.sp)
                Spacer(Modifier.height(32.dp))
                Surface(
                    color = Color(0xFF111A2B),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(18.dp)) {
                        Text("SYSTEM STATUS", color = Color(0xFF75E6FF),
                            fontSize = 10.sp, letterSpacing = 2.sp)
                        Spacer(Modifier.height(10.dp))
                        Text("AI CORE  •  NOT CONNECTED", color = Color.White, fontSize = 13.sp)
                        Spacer(Modifier.height(7.dp))
                        Text(
                            "এটি PRIYA-এর প্রাথমিক UI। Gemini AI, ভয়েস এবং চ্যাট হিস্ট্রি পরের ধাপে যুক্ত হবে।",
                            color = Color(0xFF9EADC3), fontSize = 12.sp, lineHeight = 18.sp
                        )
                    }
                }
                Spacer(Modifier.weight(1f))
                Surface(color = Color(0xFF111A2B), shape = RoundedCornerShape(28.dp),
                    modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(horizontal = 18.dp, vertical = 17.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text("এখানে লিখে কথা বলো…", color = Color(0xFF8292AA),
                            modifier = Modifier.weight(1f), fontSize = 14.sp)
                        Text("➤", color = Color(0xFF75E6FF), fontSize = 20.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("NATIVE ANDROID  •  VERSION 0.1.0",
                    color = Color(0xFF53627A), fontSize = 9.sp, letterSpacing = 1.5.sp)
            }
        }
    }
}

@Composable
private fun HologramOrb() {
    Box(Modifier.size(220.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(210.dp)) {
            val c = center
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color(0x6675E6FF), Color(0x227B6DFF), Color.Transparent),
                    center = c, radius = size.minDimension / 2
                )
            )
            drawCircle(Color(0x8875E6FF), size.minDimension * .42f,
                style = Stroke(1.5.dp.toPx()))
            drawCircle(Color(0x55B69CFF), size.minDimension * .34f,
                style = Stroke(1.dp.toPx()))
            drawCircle(Color(0xFF9DEEFF), size.minDimension * .19f)
            drawCircle(Color(0xFF183B67), size.minDimension * .15f)
        }
    }
}
