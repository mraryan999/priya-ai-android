# PRIYA Android Starter

A native Android starter project built with Kotlin and Jetpack Compose.

## Current scope
- Futuristic dark home screen
- Holographic orb placeholder
- Initial Bengali greeting
- GitHub Actions workflow to build a debug APK

## Build
Open this project in Android Studio and run `gradle assembleDebug`, or push it to GitHub and run the **Android CI** workflow under Actions.

The first version is a UI starter only. Gemini integration, secure backend, speech recognition, text-to-speech, and local chat history are not connected yet. Never put a Gemini API key in the Android app or repository.
